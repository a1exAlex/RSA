import Foundation

/// Простой сканер данных, который потребляет байты
/// из необработанных данных и сохраняет обновленную позицию.
private class Scanner {
    
    enum ScannerError: Error {
        case outOfBounds
    }
    
    let data: Data
    var index: Int = 0
    
    /// Возвращает, нет ли больше данных для потребления
    var isComplete: Bool {
        return index >= data.count
    }
    
    /// Создает сканер с предоставленными данными
    ///
    /// - Данные параметров: данные для потребления
    init(data: Data) {
        self.data = data
    }
    
    /// Использует данные заданной длины и возвращает их
    ///
    /// - Длина параметра: длина данных для потребления
    /// - Возвращает: данные использованы
    /// - Выдает: ошибка ScannerError.outOfBounds, если запрашивается слишком много байтов
    
    func consume(length: Int) throws -> Data {
        
        guard length > 0 else {
            return Data()
        }
        
        guard index + length <= data.count else {
            throw ScannerError.outOfBounds
        }
        
        let subdata = data.subdata(in: index..<index + length)
        index += length
        return subdata
    }
    
    /// Потребляет примитивную, определенную длину ASN1 и возвращает ее значение.
    /// - Краткая форма. Один октет Бит 8 имеет значение "0", а биты 7-1 дают длину.
    /// - Длинная форма. От двух до 127 октетов. Бит 8 первого октета имеет значение «1» и
    /// биты 7-1 дают число октетов дополнительной длины.
    /// Второй и последующие октеты дают длину, основание 256, самую старшую цифру первой.
    ///
    /// - Возвращает: длина, которая была израсходована
    /// - Выдает: ошибка ScannerError.outOfBounds, если запрашивается слишком много байтов
    func consumeLength() throws -> Int {
        
        let lengthByte = try consume(length: 1).firstByte
        
        // Если значение первого байта меньше 0x80, оно напрямую содержит длину
                          // чтобы мы могли его вернуть
        guard lengthByte >= 0x80 else {
            return Int(lengthByte)
        }
        
        // Если значение первого байта больше 0x80, оно указывает, сколько следующих байтов
        // опишу длину. Например, 0x85 указывает, что 0x85 - 0x80 = 0x05 = 5
        // байты будут описывать длину, поэтому нам нужно прочитать 5 следующих байтов и получить их целое число
        // значение для определения длины.
        let nextByteCount = lengthByte - 0x80
        let length = try consume(length: Int(nextByteCount))
        
        return length.integer
    }
}

private extension Data {
    
    /// Возвращает первый байт текущих данных
    var firstByte: UInt8 {
        var byte: UInt8 = 0
        copyBytes(to: &byte, count: MemoryLayout<UInt8>.size)
        return byte
    }
    
    /// Возвращает целочисленное значение текущих данных.
    /// @warning: это поддерживает только данные размером до 4 байтов, так как мы можем извлечь только 32-битные целые числа.
    var integer: Int {
        
        guard count > 0 else {
            return 0
        }
        
        var int: UInt32 = 0
        var offset: Int32 = Int32(count - 1)
        forEach { byte in
            let byte32 = UInt32(byte)
            let shifted = byte32 << (UInt32(offset) * 8)
            int = int | shifted
            offset -= 1
        }
        
        return Int(int)
    }
}

/// Простой парсер ASN1, который будет рекурсивно перебирать корневой узел и возвращать дерево узлов.
/// Корневой узел может быть любым из поддерживаемых узлов, описанных в `Node`. Если парсер встречает последовательность
/// он будет рекурсивно разбирать своих детей.
enum Asn1Parser {
    
    /// Узел ASN1
    enum Node {
        case sequence(nodes: [Node])
        case integer(data: Data)
        case objectIdentifier(data: Data)
        case null
        case bitString(data: Data)
        case octetString(data: Data)
    }
    
    enum ParserError: Error {
        case noType
        case invalidType(value: UInt8)
    }
    
    /// Анализирует данные ASN1 и возвращает его корневой узел.
    ///
    /// - Данные параметров: данные ASN1 для анализа
    /// - Возвращает: корневой узел ASN1
    /// - Выдает: ParserError, если что-то идет не так, или если обнаружен неизвестный узел
    static func parse(data: Data) throws -> Node {
        let scanner = Scanner(data: data)
        let node = try parseNode(scanner: scanner)
        return node
    }
    
    /// Анализирует ASN1 с учетом существующего сканирования.
    /// @warning: это изменит состояние (то есть: положение) предоставленного сканера.
    ///
    /// - Сканер параметров: Сканер, используемый для потребления данных
    /// - Возвращает: проанализированный узел
    /// - Выдает: ParserError, если что-то идет не так, или если обнаружен неизвестный узел
    private static func parseNode(scanner: Scanner) throws -> Node {
        
        let firstByte = try scanner.consume(length: 1).firstByte
        
        // последовательность
        if firstByte == 0x30 {
            let length = try scanner.consumeLength()
            let data = try scanner.consume(length: length)
            let nodes = try parseSequence(data: data)
            return .sequence(nodes: nodes)
        }
        
        // Целое число
        if firstByte == 0x02 {
            let length = try scanner.consumeLength()
            let data = try scanner.consume(length: length)
            return .integer(data: data)
        }
        
        // Идентификатор объекта
        if firstByte == 0x06 {
            let length = try scanner.consumeLength()
            let data = try scanner.consume(length: length)
            return .objectIdentifier(data: data)
        }
        
        // Null
        if firstByte == 0x05 {
            _ = try scanner.consume(length: 1)
            return .null
        }
        
        // Битовая строка
        if firstByte == 0x03 {
            let length = try scanner.consumeLength()
            
            // Во всех ключах, с которыми я столкнулся, после длины строки битов есть дополнительный байт (0x00).
            // Я не смог найти спецификацию, которая ссылалась на этот дополнительный байт, но давайте его поглотим и отбросим.
            _ = try scanner.consume(length: 1)
            
            let data = try scanner.consume(length: length - 1)
            return .bitString(data: data)
        }
        
        // Строка октета
        if firstByte == 0x04 {
            let length = try scanner.consumeLength()
            let data = try scanner.consume(length: length)
            return .octetString(data: data)
        }
        
        throw ParserError.invalidType(value: firstByte)
    }
    
    /// Анализирует последовательность ASN1 и возвращает ее дочерние узлы
    ///
    /// - Данные параметров: данные ASN1
    /// - Возвращает: список узлов ASN1
    /// - Выдает: ParserError, если что-то идет не так, или если обнаружен неизвестный узел
    private static func parseSequence(data: Data) throws -> [Node] {
        let scanner = Scanner(data: data)
        var nodes: [Node] = []
        while !scanner.isComplete {
            let node = try parseNode(scanner: scanner)
            nodes.append(node)
        }
        return nodes
    }
}
