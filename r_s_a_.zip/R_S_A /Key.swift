import Foundation
import Security

public protocol Key: class {
    
    var reference: SecKey { get }
    var originalData: Data? { get }
    
    init(data: Data) throws
    init(reference: SecKey) throws
    init(base64Encoded base64String: String) throws
    init(pemEncoded pemString: String) throws
    init(pemNamed pemName: String, in bundle: Bundle) throws
    init(derNamed derName: String, in bundle: Bundle) throws
    
    func pemString() throws -> String
    func data() throws -> Data
    func base64String() throws -> String
}

public extension Key {
    
    /// Возвращает представление открытого ключа в Base64.
              ///
              /// - Возвращает: данные ключа, закодированные в Base64
              /// - Броски: SwiftyRSAError
    func base64String() throws -> String {
        return try data().base64EncodedString()
    }
    
    func data() throws -> Data {
        return try SwiftyRSA.data(forKeyReference: reference)
    }
    
    /// Создает открытый ключ с строкой в кодировке base64.
              ///
              /// - Параметр base64String: данные открытого ключа в кодировке Base64
              /// - Броски: SwiftyRSAError
    init(base64Encoded base64String: String) throws {
        guard let data = Data(base64Encoded: base64String, options: [.ignoreUnknownCharacters]) else {
            throw SwiftyRSAError.invalidBase64String
        }
        try self.init(data: data)
    }
    
    /// Создает открытый ключ со строкой PEM.
              ///
              /// - Параметр pemString: строка открытого ключа в кодировке PEM
              /// - Броски: SwiftyRSAError
    init(pemEncoded pemString: String) throws {
        let base64String = try SwiftyRSA.base64String(pemEncoded: pemString)
        try self.init(base64Encoded: base64String)
    }
    
    /// Создает открытый ключ с файлом PEM.
              ///
              /// - Параметры:
              /// - pemName: имя файла PEM
              /// - bundle: Bundle, в котором нужно искать файл PEM. По умолчанию основной пакет.
              /// - Броски: SwiftyRSAError
    init(pemNamed pemName: String, in bundle: Bundle = Bundle.main) throws {
        guard let path = bundle.path(forResource: pemName, ofType: "pem") else {
            throw SwiftyRSAError.pemFileNotFound(name: pemName)
        }
        let keyString = try String(contentsOf: URL(fileURLWithPath: path), encoding: .utf8)
        try self.init(pemEncoded: keyString)
    }
    
    /// Cоздание a private key with a DER file.
    ///
    /// - Parameters:
    ///   - derName: Name of the DER file
    ///   - bundle: Bundle in which to look for the DER file. Defaults to the main bundle.
    /// - Throws: SwiftyRSAError
    init(derNamed derName: String, in bundle: Bundle = Bundle.main) throws {
        guard let path = bundle.path(forResource: derName, ofType: "der") else {
            throw SwiftyRSAError.derFileNotFound(name: derName)
        }
        let data = try Data(contentsOf: URL(fileURLWithPath: path))
        try self.init(data: data)
    }
}

