import Foundation

public protocol Message {
    var data: Data { get }
    var base64String: String { get }
    init(data: Data)
    init(base64Encoded base64String: String) throws
}

public extension Message {
    
    /// Base64-закодированная строка данных сообщения
    var base64String: String {
        return data.base64EncodedString()
    }
    
    /// Создает зашифрованное сообщение со строкой в кодировке base64.
              ///
              /// - Параметр base64String: закодированные в Base64 данные зашифрованного сообщения
              /// - Броски: SwiftyRSAError
    init(base64Encoded base64String: String) throws {
        guard let data = Data(base64Encoded: base64String) else {
            throw SwiftyRSAError.invalidBase64String
        }
        self.init(data: data)
    }
}
