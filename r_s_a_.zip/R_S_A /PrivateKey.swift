import Foundation
public class PrivateKey: Key {
    /// Ссылка на ключ в цепочке для ключей
    public let reference: SecKey
    /// Original data of the private key.
    /// Note that it does not contain PEM headers and holds data as bytes, not as a base 64 string.
    public let originalData: Data?
    let tag: String?
    /// Возвращает представление PEM закрытого ключа.
              ///
              /// - Возвращает: данные ключа, закодированные в PEM
              /// - Броски: SwiftyRSAError
    public func pemString() throws -> String {
        let data = try self.data()
        let pem = SwiftyRSA.format(keyData: data, withPemType: "RSA PRIVATE KEY")
        return pem
    }
/// Создает закрытый ключ со ссылкой на ключ цепочки для ключей.
     /// Этот инициализатор сгенерирует, если предоставленная ссылка на ключ не является частным ключом RSA.
     ///
     /// - ссылка на параметр: ссылка на ключ в цепочке для ключей.
     /// - Броски: SwiftyRSAError
    public required init(reference: SecKey) throws {
        
        guard SwiftyRSA.isValidKeyReference(reference, forClass: kSecAttrKeyClassPrivate) else {
            throw SwiftyRSAError.notAPrivateKey
        }
        
        self.reference = reference
        self.tag = nil
        self.originalData = nil
    }
    
/// Создает закрытый ключ с данными открытого ключа RSA.
     ///
     /// - Данные параметров: данные закрытого ключа
     /// - Броски: SwiftyRSAError
    required public init(data: Data) throws {
        self.originalData = data
        let tag = UUID().uuidString
        self.tag = tag
        let dataWithoutHeader = try SwiftyRSA.stripKeyHeader(keyData: data)
        reference = try SwiftyRSA.addKey(dataWithoutHeader, isPublic: false, tag: tag)
    }
    
    deinit {
        if let tag = tag {
            SwiftyRSA.removeKey(tag: tag)
        }
    }
}
